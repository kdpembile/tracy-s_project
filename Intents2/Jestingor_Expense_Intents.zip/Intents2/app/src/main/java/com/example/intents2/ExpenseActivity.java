package com.example.intents2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.TextView;

public class ExpenseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);

        // Intent to get data
        Intent intent = getIntent();
        ExpenseData expenseData = intent.getParcelableExtra("ExpenseData");

        // TextView
        TextView mResultTv = findViewById(R.id.resultTv);

        if (expenseData != null) {
            // Use getters to retrieve data and display it
            String text = "Date: " + expenseData.getDate() + "\nTitle: " + expenseData.getTitle()
                    + "\nDescription: " + expenseData.getDescription() + "\nAmount: " + expenseData.getAmount()
                    + "\nCategory: " + expenseData.getCategory();

            mResultTv.setText(text);
        }
    }
}
